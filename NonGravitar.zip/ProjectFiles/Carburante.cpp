#include "Carburante.hpp"

Carburante::Carburante(float x, float y) {
	X = x;
	Y = y;
	Size = 1;
	liter = 300;
	pro = false;
	Color = 2;
}


Carburante::~Carburante()
{
}
