#include "objGame.hpp"



objGame::objGame(float x,float y,float size)
{
	X = x;
	Y=y;
	Size = size;
}
objGame::objGame() {

}

objGame::~objGame()
{
}
