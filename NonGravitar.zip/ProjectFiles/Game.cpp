#include "Game.h"



Game::Game()
{
	m_sAppName = L"Non-Gravitar";
}


Game::~Game()
{
}

bool Game::OnUserCreate() {

	return true;
}
bool OnUserUpdate(float fElapsedTime) {

	return true;
}